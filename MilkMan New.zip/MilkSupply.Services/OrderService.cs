﻿using MilkSupply.Data.Managers;
using MilkSupply.Data.Models;
using MilkSupply.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Services
{
    public class OrderService : IOrderService
    {
        #region Private Members

        private readonly OrderManager _orderManager;

        #endregion

        #region Constructor

        public OrderService(OrderManager orderManager)
        {
            _orderManager = orderManager;
        }

        #endregion

        #region Writes

        public async Task<Order> AddAsync(Order order)
        {
            return await _orderManager.AddAsync(order);
        }

        public async Task<Order> UpdateAsync(Order order)
        {
            return await _orderManager.UpdateAsync(order);
        }

        #endregion

        #region Reads

        public async Task<List<Order>> GetOrders()
        {
            return await _orderManager.GetAllAsync();
        }

        #endregion
    }
}
