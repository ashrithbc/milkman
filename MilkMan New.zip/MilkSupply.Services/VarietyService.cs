﻿using MilkSupply.Data.Managers;
using MilkSupply.Data.Models;
using MilkSupply.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Services
{
    public class VarietyService : IVarietyService
    {
        #region Private Members

        private readonly CategoryManager _categoryManager;
        private readonly VarietyManager _varietyManager;

        #endregion

        #region Constructor

        public VarietyService(CategoryManager categoryManager, VarietyManager varietyManager)
        {
            _categoryManager = categoryManager;
            _varietyManager = varietyManager;
        }

        #endregion

        #region Writes

        public async Task<Category> AddCategoryAsync(Category category)
        {
            return await _categoryManager.AddAsync(category);
        }

        public async Task<Category> UpdateCategoryAsync(Category category)
        {
            return await _categoryManager.UpdateAsync(category);
        }

        public async Task<Variety> AddVarietyAsync(Variety variety)
        {
            return await _varietyManager.AddAsync(variety);
        }

        public async Task<Variety> UpdateVarietyAsync(Variety variety)
        {
            return await _varietyManager.UpdateAsync(variety);
        }

        #endregion

        #region Reads

        public async Task<List<Category>> GetCategoriesAsync()
        {
            return await _categoryManager.GetAllAsync();
        }

        public async Task<List<Variety>> GetVarietiesAsync()
        {
            return await _varietyManager.GetAllAsync();
        }

        #endregion
    }
}
