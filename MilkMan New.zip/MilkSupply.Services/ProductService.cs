﻿using MilkSupply.Data.Managers;
using MilkSupply.Data.Models;
using MilkSupply.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Services
{
    public class ProductService : IProductService
    {
        #region Private Members

        private readonly ProductManager _productManager;

        #endregion

        #region Constructor
        public ProductService(ProductManager productManager)
        {
            _productManager = productManager;
        }
        #endregion

        #region Writes

        public async Task<Product> AddAsync(Product product)
        {
            return await _productManager.AddAsync(product);
        }

        public async Task<Product> UpdateAsync(Product product)
        {
            return await _productManager.UpdateAsync(product);
        }
        #endregion

        #region Reads

        public async Task<List<Product>> GetProduct(int id)
        {
            return await _productManager.GetAllAsync(id);
        }
        #endregion
    }
}
