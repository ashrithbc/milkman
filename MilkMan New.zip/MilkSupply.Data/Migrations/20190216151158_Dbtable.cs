﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MilkSupply.Data.Migrations
{
    public partial class Dbtable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUserTokens",
                newName: "AspNetUserTokens",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUsers",
                newName: "AspNetUsers",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUserRoles",
                newName: "AspNetUserRoles",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUserLogins",
                newName: "AspNetUserLogins",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUserClaims",
                newName: "AspNetUserClaims",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetRoles",
                newName: "AspNetRoles",
                newSchema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetRoleClaims",
                newName: "AspNetRoleClaims",
                newSchema: "Milk");

            migrationBuilder.CreateTable(
                name: "Category",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 30, nullable: true),
                    Description = table.Column<string>(maxLength: 200, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ContactDetails",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AddressLine1 = table.Column<string>(maxLength: 200, nullable: true),
                    AddressLine2 = table.Column<string>(maxLength: 200, nullable: true),
                    Town = table.Column<string>(maxLength: 200, nullable: true),
                    District = table.Column<string>(maxLength: 100, nullable: true),
                    State = table.Column<string>(maxLength: 100, nullable: true),
                    PostCode = table.Column<string>(maxLength: 6, nullable: true),
                    HomePhone = table.Column<string>(maxLength: 20, nullable: true),
                    MobilePhone = table.Column<string>(maxLength: 10, nullable: true),
                    Email = table.Column<string>(maxLength: 320, nullable: true),
                    EmailValidated = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContactDetails", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryTime",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Slot = table.Column<string>(maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryTime", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Description = table.Column<string>(maxLength: 50, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Variety",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CategoryId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(maxLength: 30, nullable: true),
                    Description = table.Column<string>(maxLength: 200, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Variety", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Variety_Category_CategoryId",
                        column: x => x.CategoryId,
                        principalSchema: "Milk",
                        principalTable: "Category",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Customer",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ContactDetailId = table.Column<int>(nullable: true),
                    Title = table.Column<string>(maxLength: 10, nullable: true),
                    Firstename = table.Column<string>(maxLength: 120, nullable: true),
                    Lastname = table.Column<string>(maxLength: 120, nullable: true),
                    Gender = table.Column<string>(maxLength: 15, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Customer_ContactDetails_ContactDetailId",
                        column: x => x.ContactDetailId,
                        principalSchema: "Milk",
                        principalTable: "ContactDetails",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Seller",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(maxLength: 120, nullable: true),
                    Gender = table.Column<string>(maxLength: 15, nullable: true),
                    ContactDetailId = table.Column<int>(nullable: true),
                    Certified = table.Column<bool>(nullable: false),
                    Notes = table.Column<string>(maxLength: 200, nullable: true),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Seller", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Seller_ContactDetails_ContactDetailId",
                        column: x => x.ContactDetailId,
                        principalSchema: "Milk",
                        principalTable: "ContactDetails",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Certificate",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SellerId = table.Column<int>(nullable: false),
                    ByteData = table.Column<string>(maxLength: 2147483647, nullable: true),
                    Verified = table.Column<bool>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Certificate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Certificate_Seller_SellerId",
                        column: x => x.SellerId,
                        principalSchema: "Milk",
                        principalTable: "Seller",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    VarietyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(maxLength: 120, nullable: true),
                    Description = table.Column<string>(maxLength: 200, nullable: true),
                    SellerId = table.Column<int>(nullable: false),
                    AvailabilityTimeId = table.Column<int>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_DeliveryTime_AvailabilityTimeId",
                        column: x => x.AvailabilityTimeId,
                        principalSchema: "Milk",
                        principalTable: "DeliveryTime",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Products_Seller_SellerId",
                        column: x => x.SellerId,
                        principalSchema: "Milk",
                        principalTable: "Seller",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Products_Variety_VarietyId",
                        column: x => x.VarietyId,
                        principalSchema: "Milk",
                        principalTable: "Variety",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Order",
                schema: "Milk",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProductId = table.Column<int>(nullable: false),
                    Quantity = table.Column<int>(nullable: false),
                    DeliveryTimeId = table.Column<int>(nullable: false),
                    CustomerId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    IsRecurring = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Order", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Order_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "Milk",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Order_DeliveryTime_DeliveryTimeId",
                        column: x => x.DeliveryTimeId,
                        principalSchema: "Milk",
                        principalTable: "DeliveryTime",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Order_Products_ProductId",
                        column: x => x.ProductId,
                        principalSchema: "Milk",
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Certificate_SellerId",
                schema: "Milk",
                table: "Certificate",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_Customer_ContactDetailId",
                schema: "Milk",
                table: "Customer",
                column: "ContactDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_CustomerId",
                schema: "Milk",
                table: "Order",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_DeliveryTimeId",
                schema: "Milk",
                table: "Order",
                column: "DeliveryTimeId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ProductId",
                schema: "Milk",
                table: "Order",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_AvailabilityTimeId",
                schema: "Milk",
                table: "Products",
                column: "AvailabilityTimeId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_SellerId",
                schema: "Milk",
                table: "Products",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_VarietyId",
                schema: "Milk",
                table: "Products",
                column: "VarietyId");

            migrationBuilder.CreateIndex(
                name: "IX_Seller_ContactDetailId",
                schema: "Milk",
                table: "Seller",
                column: "ContactDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_Variety_CategoryId",
                schema: "Milk",
                table: "Variety",
                column: "CategoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Certificate",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Order",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Status",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Customer",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Products",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "DeliveryTime",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Seller",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Variety",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "ContactDetails",
                schema: "Milk");

            migrationBuilder.DropTable(
                name: "Category",
                schema: "Milk");

            migrationBuilder.RenameTable(
                name: "AspNetUserTokens",
                schema: "Milk",
                newName: "AspNetUserTokens");

            migrationBuilder.RenameTable(
                name: "AspNetUsers",
                schema: "Milk",
                newName: "AspNetUsers");

            migrationBuilder.RenameTable(
                name: "AspNetUserRoles",
                schema: "Milk",
                newName: "AspNetUserRoles");

            migrationBuilder.RenameTable(
                name: "AspNetUserLogins",
                schema: "Milk",
                newName: "AspNetUserLogins");

            migrationBuilder.RenameTable(
                name: "AspNetUserClaims",
                schema: "Milk",
                newName: "AspNetUserClaims");

            migrationBuilder.RenameTable(
                name: "AspNetRoles",
                schema: "Milk",
                newName: "AspNetRoles");

            migrationBuilder.RenameTable(
                name: "AspNetRoleClaims",
                schema: "Milk",
                newName: "AspNetRoleClaims");
        }
    }
}
