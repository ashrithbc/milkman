﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MilkSupply.Data.Migrations
{
    public partial class fieldChanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Type",
                schema: "Milk",
                table: "Status",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SellerStatus",
                schema: "Milk",
                table: "Seller",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "OrderStatus",
                schema: "Milk",
                table: "Order",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Seller_SellerStatus",
                schema: "Milk",
                table: "Seller",
                column: "SellerStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_OrderStatus",
                schema: "Milk",
                table: "Order",
                column: "OrderStatus");

            migrationBuilder.AddForeignKey(
                name: "FK_Order_Status_OrderStatus",
                schema: "Milk",
                table: "Order",
                column: "OrderStatus",
                principalSchema: "Milk",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Seller_Status_SellerStatus",
                schema: "Milk",
                table: "Seller",
                column: "SellerStatus",
                principalSchema: "Milk",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Order_Status_OrderStatus",
                schema: "Milk",
                table: "Order");

            migrationBuilder.DropForeignKey(
                name: "FK_Seller_Status_SellerStatus",
                schema: "Milk",
                table: "Seller");

            migrationBuilder.DropIndex(
                name: "IX_Seller_SellerStatus",
                schema: "Milk",
                table: "Seller");

            migrationBuilder.DropIndex(
                name: "IX_Order_OrderStatus",
                schema: "Milk",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "Type",
                schema: "Milk",
                table: "Status");

            migrationBuilder.DropColumn(
                name: "SellerStatus",
                schema: "Milk",
                table: "Seller");

            migrationBuilder.DropColumn(
                name: "OrderStatus",
                schema: "Milk",
                table: "Order");
        }
    }
}
