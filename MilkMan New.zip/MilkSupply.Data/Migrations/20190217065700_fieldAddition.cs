﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MilkSupply.Data.Migrations
{
    public partial class fieldAddition : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                schema: "Milk",
                table: "Seller",
                newName: "LastName");

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                schema: "Milk",
                table: "Seller",
                maxLength: 120,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Amount",
                schema: "Milk",
                table: "Products",
                maxLength: 120,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "QuantityAvailable",
                schema: "Milk",
                table: "Products",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                schema: "Milk",
                table: "Order",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                schema: "Milk",
                table: "ContactDetails",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                schema: "Milk",
                table: "Seller");

            migrationBuilder.DropColumn(
                name: "Amount",
                schema: "Milk",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "QuantityAvailable",
                schema: "Milk",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "IsActive",
                schema: "Milk",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "IsActive",
                schema: "Milk",
                table: "ContactDetails");

            migrationBuilder.RenameColumn(
                name: "LastName",
                schema: "Milk",
                table: "Seller",
                newName: "Name");
        }
    }
}
