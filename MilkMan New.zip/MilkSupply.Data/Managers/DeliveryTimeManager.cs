﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class DeliveryTimeManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public DeliveryTimeManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add DeliveryTime
        public async Task<DeliveryTime> AddAsync(DeliveryTime DeliveryTime)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<DeliveryTime> categories = ctx.Set<DeliveryTime>();
                categories.Add(DeliveryTime);
                await ctx.SaveChangesAsync();
            }
            return DeliveryTime;
        }

        //Update DeliveryTime
        public async Task<DeliveryTime> UpdateAsync(DeliveryTime DeliveryTime)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<DeliveryTime> categories = ctx.Set<DeliveryTime>();
                categories.Update(DeliveryTime);
                await ctx.SaveChangesAsync();
            }
            return DeliveryTime;
        }

        //Get All Categories
        public async Task<List<DeliveryTime>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.DeliveryTime
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }

        }
    }
}
