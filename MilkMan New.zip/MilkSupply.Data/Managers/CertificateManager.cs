﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    class CertificateManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public CertificateManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
        
            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Certificate
        public async Task<Certificate> AddAsync(Certificate Certificate)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Certificate> categories = ctx.Set<Certificate>();
                categories.Add(Certificate);
                await ctx.SaveChangesAsync();
            }
            return Certificate;
        }

        //Update Certificate
        public async Task<Certificate> UpdateAsync(Certificate Certificate)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Certificate> categories = ctx.Set<Certificate>();
                categories.Update(Certificate);
                await ctx.SaveChangesAsync();
            }
            return Certificate;
        }

        //Get All Categories
        public async Task<List<Certificate>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Certificate
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }
        }
    }
}
