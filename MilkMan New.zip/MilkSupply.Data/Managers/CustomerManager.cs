﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class CustomerManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public CustomerManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Customer
        public async Task<Customer> AddAsync(Customer Customer)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Customer> categories = ctx.Set<Customer>();
                categories.Add(Customer);
                await ctx.SaveChangesAsync();
            }
            return Customer;
        }

        //Update Customer
        public async Task<Customer> UpdateAsync(Customer Customer)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Customer> categories = ctx.Set<Customer>();
                categories.Update(Customer);
                await ctx.SaveChangesAsync();
            }
            return Customer;
        }

        //Get All Categories
        public async Task<List<Customer>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Customer
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }

        }
    }
}
