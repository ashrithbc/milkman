﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class VarietyManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public VarietyManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Variety
        public async Task<Variety> AddAsync(Variety Variety)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Variety> categories = ctx.Set<Variety>();
                categories.Add(Variety);
                await ctx.SaveChangesAsync();
            }
            return Variety;
        }

        //Update Variety
        public async Task<Variety> UpdateAsync(Variety Variety)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Variety> categories = ctx.Set<Variety>();
                categories.Update(Variety);
                await ctx.SaveChangesAsync();
            }
            return Variety;
        }

        //Get All Categories
        public async Task<List<Variety>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Variety
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }
        }
    }
}
