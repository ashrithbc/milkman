﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class StatusManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public StatusManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Status
        public async Task<Status> AddAsync(Status Status)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Status> categories = ctx.Set<Status>();
                categories.Add(Status);
                await ctx.SaveChangesAsync();
            }
            return Status;
        }

        //Update Status
        public async Task<Status> UpdateAsync(Status Status)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Status> categories = ctx.Set<Status>();
                categories.Update(Status);
                await ctx.SaveChangesAsync();
            }
            return Status;
        }

        //Get All Categories
        public async Task<List<Status>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Status
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }
        }
    }
}
