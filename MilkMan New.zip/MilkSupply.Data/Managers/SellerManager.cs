﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class SellerManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public SellerManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }
        #endregion

        //Add Seller
        public async Task<Seller> AddAsync(Seller Seller)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Seller> categories = ctx.Set<Seller>();
                categories.Add(Seller);
                await ctx.SaveChangesAsync();
            }
            return Seller;
        }

        //Update Seller
        public async Task<Seller> UpdateAsync(Seller Seller)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Seller> categories = ctx.Set<Seller>();
                categories.Update(Seller);
                await ctx.SaveChangesAsync();
            }
            return Seller;
        }

        //Get All Categories
        public async Task<List<Seller>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Seller
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }

        }
    }
}
