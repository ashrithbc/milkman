﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class CategoryManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public CategoryManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Category
        public async Task<Category> AddAsync(Category category)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Category> categories = ctx.Set<Category>();
                categories.Add(category);
                await ctx.SaveChangesAsync();
            }
            return category;
        }

        //Update Category
        public async Task<Category> UpdateAsync(Category category)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Category> categories = ctx.Set<Category>();
                categories.Update(category);
                await ctx.SaveChangesAsync();
            }
            return category;
        }

        //Get All Categories
        public async Task<List<Category>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Category
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }
        }
    }
}
