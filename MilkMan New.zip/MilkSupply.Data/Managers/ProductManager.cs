﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class ProductManager
    {

        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public ProductManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Product
        public async Task<Product> AddAsync(Product Product)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Product> categories = ctx.Set<Product>();
                categories.Add(Product);
                await ctx.SaveChangesAsync();
            }
            return Product;
        }

        //Update Product
        public async Task<Product> UpdateAsync(Product Product)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Product> categories = ctx.Set<Product>();
                categories.Update(Product);
                await ctx.SaveChangesAsync();
            }
            return Product;
        }

        //Get All Categories
        public async Task<List<Product>> GetAllAsync(int varietyId)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                IQueryable<Product> query = ctx.Product
                    .Include(x => x.Seller);

                if (varietyId == 0)
                {
                    query = query.Where(x => x.IsActive);
                }
                else if (varietyId > 0)
                {
                    query = query.Where(x => x.IsActive && x.VarietyId == varietyId);
                }
                return await query.ToListAsync();
            }
        }
    }
}
