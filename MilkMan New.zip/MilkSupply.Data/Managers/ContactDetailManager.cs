﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class ContactDetailManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public ContactDetailManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add ContactDetail
        public async Task<ContactDetail> AddAsync(ContactDetail ContactDetail)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<ContactDetail> categories = ctx.Set<ContactDetail>();
                categories.Add(ContactDetail);
                await ctx.SaveChangesAsync();
            }
            return ContactDetail;
        }

        //Update ContactDetail
        public async Task<ContactDetail> UpdateAsync(ContactDetail ContactDetail)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<ContactDetail> categories = ctx.Set<ContactDetail>();
                categories.Update(ContactDetail);
                await ctx.SaveChangesAsync();
            }
            return ContactDetail;
        }

        //Get All Categories
        public async Task<List<ContactDetail>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.ContactDetail
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }
        }
    }
}
