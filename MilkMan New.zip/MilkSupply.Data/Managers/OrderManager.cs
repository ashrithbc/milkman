﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MilkSupply.Data.Context;
using MilkSupply.Data.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MilkSupply.Data.Managers
{
    public class OrderManager
    {
        #region Private Member

        private readonly DbContextOptionsBuilder<MilkContext> _optionsBuilder;

        #endregion

        #region Constructor

        public OrderManager()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            _optionsBuilder = new DbContextOptionsBuilder<MilkContext>();
            var connectionString = configuration.GetConnectionString("milk");
            _optionsBuilder.UseSqlServer(connectionString);
        }

        #endregion

        //Add Order
        public async Task<Order> AddAsync(Order Order)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Order> categories = ctx.Set<Order>();
                categories.Add(Order);
                await ctx.SaveChangesAsync();
            }
            return Order;
        }

        //Update Order
        public async Task<Order> UpdateAsync(Order Order)
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                DbSet<Order> categories = ctx.Set<Order>();
                categories.Update(Order);
                await ctx.SaveChangesAsync();
            }
            return Order;
        }

        //Get All Categories
        public async Task<List<Order>> GetAllAsync()
        {
            using (MilkContext ctx = new MilkContext(_optionsBuilder.Options))
            {
                return await ctx.Order
                    .Where(x => x.IsActive)
                    .ToListAsync();
            }

        }
    }
}
