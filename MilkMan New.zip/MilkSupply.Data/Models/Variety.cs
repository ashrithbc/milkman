﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Variety", Schema = "Milk")]
    public class Variety
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("Category")]
        public int CategoryId { get; set; }
        [MaxLength(30)]
        [DataType("nvarchar")]
        public string Name { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string Description { get; set; }
        public bool IsActive { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
