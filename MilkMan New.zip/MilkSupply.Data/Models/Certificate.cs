﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    public class Certificate
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("Seller")]
        public int SellerId { get; set; }
        [MaxLength(Int32.MaxValue)]
        [DataType("nvarchar")]
        public string ByteData { get; set; }
        public bool Verified { get; set; }
        public bool IsActive { get; set; }

        public virtual Seller Seller { get; set; }
    }
}
