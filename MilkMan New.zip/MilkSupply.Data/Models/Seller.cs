﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Seller")]
    public class Seller
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(120)]
        [DataType("nvarchar")]
        public string FirstName { get; set; }
        [MaxLength(120)]
        [DataType("nvarchar")]
        public string LastName { get; set; }

        [MaxLength(15)]
        [DataType("nvarchar")]
        public string Gender { get; set; }
        [ForeignKey("ContactDetail")]
        public int? ContactDetailId { get; set; }
        public bool Certified { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string Notes { get; set; }
        public bool IsActive { get; set; }
        [ForeignKey("Status")]
        public int SellerStatus { get; set; }

        public virtual ContactDetail ContactDetail { get; set; }
        public virtual Status Status { get; set; }

        public virtual ICollection<Product> Products { get; set; }
        public virtual ICollection<Certificate> Certifiates { get; set; }
    }
}
