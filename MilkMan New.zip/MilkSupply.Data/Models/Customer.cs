﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Customer")]
    public class Customer
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("ContactDetail")]
        public int? ContactDetailId { get; set; }
        [MaxLength(10)]
        [DataType("varchar")]
        public string Title { get; set; }
        [MaxLength(120)]
        [DataType("varchar")]
        public string Firstename { get; set; }
        [MaxLength(120)]
        [DataType("varchar")]
        public string Lastname { get; set; }
        [MaxLength(15)]
        [DataType("varchar")]
        public string Gender { get; set; }              
        public bool IsActive { get; set; }

        public virtual ContactDetail ContactDetail { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}