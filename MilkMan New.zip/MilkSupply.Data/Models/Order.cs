﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Order")]
    public class Order
    {
        public int Id { get; set; }

        [ForeignKey("Product")]
        public int ProductId { get; set; }

        public int Quantity { get; set; }
        [ForeignKey("DeliveryTime")]
        public int DeliveryTimeId { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        [MaxLength(1000)]
        [DataType("varchar")]
        public string Description { get; set; }
        public bool IsRecurring { get; set; }
        [ForeignKey("Status")]
        public int OrderStatus { get; set; }
        
        public virtual Product Product { get; set; }
        public virtual Customer Customer { get; set; }
        public virtual DeliveryTime DeliveryTime { get; set; }
        public virtual Status Status { get; set; }
        public bool IsActive { get; internal set; }
    }
}
