﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("DeliveryTime", Schema = "Milk")]
    public class DeliveryTime
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(20)]
        [DataType("nvarchar")]
        public string Slot {get;set;}
        public bool IsActive { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
