﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Category", Schema = "Milk")]
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(30)]
        [DataType("nvarchar")]
        public string Name { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string Description { get; set; }
        public bool IsActive { get; set; }

        public ICollection<Variety> Varieties { get; set; }
    }
}
