﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("ContactDetails")]
    public class ContactDetail
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string AddressLine1 { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string AddressLine2 { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string Town { get; set; }
        [MaxLength(100)]
        [DataType("nvarchar")]
        public string District { get; set; }
        [MaxLength(100)]
        [DataType("nvarchar")]
        public string State { get; set; }
        [MaxLength(6)]
        [DataType("nvarchar")]
        public string PostCode { get; set; }
        [MaxLength(20)]
        [DataType("nvarchar")]
        public string HomePhone { get; set; }
        [MaxLength(10)]
        [DataType("nvarchar")]
        public string MobilePhone { get; set; }
        [MaxLength(320)]
        [DataType("nvarchar")]
        public string Email { get; set; }
        public bool EmailValidated { get; set; }

        public virtual ICollection<Customer> Customers { get; set; }
        public virtual ICollection<Seller> Sellers { get; set; }
        public bool IsActive { get; internal set; }
    }
}
