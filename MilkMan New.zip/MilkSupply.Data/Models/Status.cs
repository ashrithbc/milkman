﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MilkSupply.Data.Models
{
    public class Status
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(50)]
        [DataType("nvarchar")]
        public string Description { get; set; }
        [MaxLength(50)]
        [DataType("nvarchar")]
        public string Type { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<Seller> Sellers { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}
