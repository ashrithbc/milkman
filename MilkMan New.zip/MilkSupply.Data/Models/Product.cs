﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilkSupply.Data.Models
{
    [Table("Products", Schema = "Milk")]
    public class Product
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("Variety")]
        public int VarietyId { get; set; }
        [MaxLength(120)]
        [DataType("varchar")]
        public string Name { get; set; }
        [MaxLength(200)]
        [DataType("nvarchar")]
        public string Description { get; set; }
        [ForeignKey("Seller")]
        public int SellerId { get; set; }
        [ForeignKey("AvailabilityTime")]
        public int AvailabilityTimeId { get; set; }
        public bool IsActive { get; set; }
        [MaxLength(120)]
        [DataType("nvarchar")]
        public string Amount { get; set; }
        public string QuantityAvailable { get; set; }

        public virtual Variety Variety { get; set; }
        public virtual Seller Seller { get; set; }
        public virtual DeliveryTime AvailabilityTime { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
