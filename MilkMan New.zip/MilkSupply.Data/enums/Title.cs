﻿namespace MilkSupply.Data.enums
{
    public enum Title
    {
        Mr = 1,
        Mrs = 2,
        Miss = 3,
        Master = 4,
        Prof = 5,
        Dr = 6
    }
}