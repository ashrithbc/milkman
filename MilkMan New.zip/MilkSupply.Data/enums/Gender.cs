﻿namespace MilkSupply.Data.enums
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}