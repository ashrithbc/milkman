﻿namespace MilkSupply.Data.enums
{
    public enum Role : int
    {
        Root = 1,
        Admin = 2,
        Seller = 3,
        Customer = 4
    }
}
