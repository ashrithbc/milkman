﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MilkSupply.Data.Models;

namespace MilkSupply.Data.Context
{
    public class MilkContext : IdentityDbContext<IdentityUser, IdentityRole, string>
    {
        private readonly DbContextOptions<MilkContext> _options;

        public MilkContext(DbContextOptions<MilkContext> options)
            : base(options)
        {
            _options = options;

        }

        public DbSet<Category> Category { get; set; }
        public DbSet<Certificate> Certificate { get; set; }
        public DbSet<ContactDetail> ContactDetail { get; set; }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<DeliveryTime> DeliveryTime { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<Seller> Seller { get; set; }
        public DbSet<Status> Status { get; set; }
        public DbSet<Variety> Variety { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.HasDefaultSchema("Milk");
        }
    }
}
