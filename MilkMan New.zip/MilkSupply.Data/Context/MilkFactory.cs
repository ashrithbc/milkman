﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace MilkSupply.Data.Context
{
    public class MilkFactory : IDesignTimeDbContextFactory<MilkContext>
    {
        public MilkContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var builder = new DbContextOptionsBuilder<MilkContext>();

            var connectionString = configuration.GetConnectionString("milk");

            builder//.UseLazyLoadingProxies()
                .UseSqlServer(connectionString);


            return new MilkContext(builder.Options);
        }
    }
}
