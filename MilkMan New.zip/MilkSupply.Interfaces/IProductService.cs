﻿using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Interfaces
{
    public interface IProductService
    {
        Task<Product> AddAsync(Product product);
        Task<Product> UpdateAsync(Product product);
        Task<List<Product>> GetProduct(int varietyId);
    }
}
