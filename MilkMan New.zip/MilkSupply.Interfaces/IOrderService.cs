﻿using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Interfaces
{
    public interface IOrderService
    {
        Task<Order> AddAsync(Order order);
        Task<Order> UpdateAsync(Order order);

        Task<List<Order>> GetOrders();
    }
}
