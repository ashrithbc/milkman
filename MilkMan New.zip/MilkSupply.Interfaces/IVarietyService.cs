﻿using MilkSupply.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilkSupply.Interfaces
{
    public interface IVarietyService
    {
        Task<Category> AddCategoryAsync(Category category);
        Task<Category> UpdateCategoryAsync(Category category);

        Task<Variety> AddVarietyAsync(Variety variety);
        Task<Variety> UpdateVarietyAsync(Variety variety);

        Task<List<Category>> GetCategoriesAsync();
        Task<List<Variety>> GetVarietiesAsync();
    }
}
