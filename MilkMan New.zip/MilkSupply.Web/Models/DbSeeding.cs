﻿using Microsoft.AspNetCore.Identity;
using MilkSupply.Data.enums;
using System;
using System.Threading.Tasks;

namespace MilkSupply.Web.Models
{
    public class DbSeeding
    {
        public static async Task Initialize(UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            //Seeding of User Roles
            await CreateRoles(roleManager, Role.Root.ToString(), "Root");
            await CreateRoles(roleManager, Role.Admin.ToString(), "Admin");
            await CreateRoles(roleManager, Role.Seller.ToString(), "Seller");
            await CreateRoles(roleManager, Role.Customer.ToString(), "Customer");

            IdentityUser user = await userManager.FindByNameAsync("rootuser");
            if (user == null)
            {
                IdentityUser iUser = new IdentityUser { Email = "rootuser@milk.com", UserName = "rootuser" };
                await CreateUser(iUser, userManager, Role.Root.ToString());
            }

            IdentityUser adminUser = await userManager.FindByNameAsync("adminuser");
            if (adminUser == null)
            {
                IdentityUser iUser = new IdentityUser { Email = "adminuser@milk.com", UserName = "adminuser" };
                await CreateUser(iUser, userManager, Role.Admin.ToString());
            }
        }

        private static async Task CreateRoles(RoleManager<IdentityRole> roleManager, string roleName, string normalisedName)
        {
            try
            {
                bool roleExists = await roleManager.RoleExistsAsync(roleName);
                if (!roleExists)
                {
                    IdentityRole iRole = new IdentityRole { Name = roleName, NormalizedName = normalisedName };
                    await roleManager.CreateAsync(iRole);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static async Task CreateUser(IdentityUser user, UserManager<IdentityUser> userManager, string role)
        {

            IdentityResult result = await userManager.CreateAsync(user, "Abcd@1234");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(user, role);
                //User user = new User { Name = "Root", Email = "exclusiveroot" };
                //context.User.Add(user);
                //context.SaveChanges();
            }
        }
    }
}
