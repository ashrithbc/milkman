﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MilkSupply.Web.Models
{
    public class ProductModel
    {
        public int Id { get; set; }
        [DisplayName("Variety *")]
        public int VarietyId { get; set; }
        public List<SelectListItem> Varieties { get; set; }
        [Required(ErrorMessage = "Product Name is required")]
        [MaxLength(120)]
        [DisplayName("Name *")]
        public string Name { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Description *")]
        public string Description { get; set; }
        public int SellerId { get; set; }

        [Required]
        [DisplayName("Quantity Available *")]
        public int QuantityAvailable { get; set; }

        [Required]
        [DisplayName("Time slot *")]
        public int AvailabilityTimeId { get; set; }
        public List<SelectListItem> Slots { get; set; }
        public bool IsActive { get; set; }
        [DisplayName("Amount in rupee *")]
        public decimal Amount { get; set; }

        public SellerModel Seller { get; set; }


        public ProductModel()
        {
            Seller = new SellerModel();
            Varieties = new List<SelectListItem>();
            Slots = new List<SelectListItem>();
        }
    }
}
