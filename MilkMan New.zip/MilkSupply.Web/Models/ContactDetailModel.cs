﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MilkSupply.Web.Models
{
    public class ContactDetailModel
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Address 1*")]
        public string AddressLine1 { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Address 2*")]
        public string AddressLine2 { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Town *")]
        public string Town { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("District *")]
        public string District { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("State *")]
        public string State { get; set; }
        [Required]
        [MaxLength(6)]
        [DisplayName("Post Code *")]
        public string PostCode { get; set; }
        [MaxLength(20)]
        [DisplayName("Contact number(home)")]
        public string HomePhone { get; set; }
        [Required]
        [MaxLength(10)]
        [DisplayName("Personal number *")]
        public string MobilePhone { get; set; }
        [Required]
        [MaxLength(320)]
        [DisplayName("Email ID *")]
        [EmailAddress]
        public string Email { get; set; }
        public bool EmailValidated { get; set; }
    }
}
