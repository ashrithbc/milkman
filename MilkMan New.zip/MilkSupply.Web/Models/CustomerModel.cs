﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MilkSupply.Web.Models
{
    public class CustomerModel
    {       
        public int Id { get; set; }
        [Required]
        public int? ContactDetailId { get; set; }
        [Required]
        public int Title { get; set; }
        public List<SelectListItem> Titles { get; set; }
        [Required]
        [MaxLength(120)]
        [DisplayName("First Name *")]
        public string Firstname { get; set; }
        [Required]
        [MaxLength(120)]
        [DisplayName("Last Name *")]
        public string Lastname { get; set; }
        [Required]
        public int Gender { get; set; }
        public List<SelectListItem> GenderList { get; set; }
        public bool IsActive { get; set; }
        public int ContactId { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Address 1*")]
        public string AddressLine1 { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Address 2*")]
        public string AddressLine2 { get; set; }
        [Required]
        [MaxLength(200)]
        [DisplayName("Town *")]
        public string Town { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("District *")]
        public string District { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("State *")]
        public string State { get; set; }
        [Required]
        [MaxLength(6)]
        [DisplayName("Post Code*")]
        public string PostCode { get; set; }
        [MaxLength(20)]
        [DisplayName("Contact number(home)")]
        public string HomePhone { get; set; }
        [Required]
        [MaxLength(10)]
        [DisplayName("Personal number*")]
        public string MobilePhone { get; set; }
        [Required]
        [MaxLength(320)]
        [DisplayName("Email ID*")]
        [EmailAddress]
        public string Email { get; set; }
        public bool EmailValidated { get; set; }

        [Required(ErrorMessage = "Username is required")]
        [MinLength(3)]
        [MaxLength(50)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,48}$", ErrorMessage = "Passwords must be at least 8 characters and contain at 3 of 4 of the following: upper case (A-Z), lower case (a-z), number (0-9) and special character (e.g. !@#$%^&*)")]
        [DisplayName("*Password:")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Confirm Password is required")]
        [Compare("Password", ErrorMessage = "Password and confirm password do not match.")]
        [DisplayName("*Confirm Password:")]
        public string ConfirmPassword { get; set; }

        public CustomerModel()
        {
            Titles = new List<SelectListItem>();
            GenderList = new List<SelectListItem>();
        }
    }
}
