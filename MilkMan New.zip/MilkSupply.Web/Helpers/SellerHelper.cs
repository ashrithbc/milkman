﻿using System.Linq;
using System.Threading.Tasks;
using MilkSupply.Data.Managers;
using MilkSupply.Data.Models;
using MilkSupply.Web.Models;


namespace MilkSupply.Web.Helpers
{
    public class SellerHelper
    {
        public static async Task<Seller> MaptoDataModel(SellerModel source)
        {
            StatusManager manager = new StatusManager();
            var status = await manager.GetAllAsync();
            var seller = new Seller
            {
                FirstName = source.FirstName,
                LastName = source.LastName,
                Gender = source.Gender.ToString(),
                IsActive = source.IsActive,
                Id = source.Id,
                Certified = source.Certified,
                Notes = source.Notes,
                SellerStatus = status.FirstOrDefault(x => x.Type == "Seller" && x.Description == "New").Id,

                ContactDetail = new ContactDetail
                {
                    AddressLine1 = source.AddressLine1,
                    AddressLine2 = source.AddressLine2,
                    Town = source.Town,
                    District = source.District,
                    State = source.State,
                    PostCode = source.PostCode,
                    HomePhone = source.HomePhone,
                    MobilePhone = source.MobilePhone,
                    Email = source.Email
                }
            };
            if (source.ContactDetailId.HasValue)
            {
                seller.ContactDetail.Id = source.ContactDetailId.Value;
            }

            return seller;
        }
    }
}
