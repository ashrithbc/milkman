﻿using System;
using MilkSupply.Web.Models;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;

namespace MilkSupply.Web.Helpers
{
    public static class ProductHelper
    {
        public static async Task MapToViewModel(List<Data.Models.Product> source, List<ProductModel> destination)
        {
            destination = new List<ProductModel>();

            foreach (var prod in source)
            {
                destination.Add(new ProductModel
                {
                    //Amount = source
                    AvailabilityTimeId = prod.AvailabilityTimeId,
                    Description = prod.Description,
                    Id = prod.Id,
                    IsActive = prod.IsActive,
                    Name = prod.Name,
                    VarietyId = prod.VarietyId,
                    SellerId = prod.SellerId,
                    Seller = new SellerModel
                    {
                        IsActive = prod.Seller.IsActive,
                        ContactDetailId = prod.Seller.ContactDetailId,
                        FirstName = prod.Seller.FirstName,
                        LastName = prod.Seller.LastName
                    }
                });
            }
        }

        public static Data.Models.Product MapToDataModel(ProductModel pro)
        {
            try
            {
                return new Data.Models.Product
                {
                    Name = pro.Name,
                    Amount = pro.Amount.ToString(CultureInfo.InvariantCulture),
                    AvailabilityTimeId = pro.AvailabilityTimeId,
                    Description = pro.Description,
                    IsActive = true,
                    QuantityAvailable = pro.QuantityAvailable.ToString(),
                    SellerId = 3, //for instance
                    VarietyId = pro.VarietyId
                };
            }
            catch (Exception)
            {
            }

            return null;
        }
    }
}
