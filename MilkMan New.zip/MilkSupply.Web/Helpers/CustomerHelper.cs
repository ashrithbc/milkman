﻿using MilkSupply.Data.Models;
using MilkSupply.Web.Models;
using System.Threading.Tasks;

namespace MilkSupply.Web.Helpers
{
    public class CustomerHelper
    {
        public static async Task<Customer> MaptoDataModel(CustomerModel source)
        {
            return new Customer
            {
                Firstename = source.Firstname,
                Lastname = source.Lastname,
                Gender = source.Gender.ToString(),
                IsActive = source.IsActive,
                Title = source.Title.ToString(),
                Id = source.Id,
                ContactDetailId = source.ContactDetailId,
                ContactDetail = new ContactDetail
                {
                    Id = source.ContactId,
                    AddressLine1 = source.AddressLine1,
                    AddressLine2 = source.AddressLine2,
                    Town = source.Town,
                    District = source.District,
                    State = source.State,
                    PostCode = source.PostCode,
                    HomePhone = source.HomePhone,
                    MobilePhone = source.MobilePhone,
                    Email = source.Email
                }
            };
        }
    }
}
