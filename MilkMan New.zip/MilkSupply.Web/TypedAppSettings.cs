﻿namespace MilkSupply.Web
{
    public class TypedAppSettings
    {
        public string AppPath { get; set; }
    }
}
