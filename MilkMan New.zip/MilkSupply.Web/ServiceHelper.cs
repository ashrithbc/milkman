﻿using Microsoft.Extensions.DependencyInjection;
using MilkSupply.Interfaces;

namespace MilkSupply.Web
{
    public sealed class ServiceHelper
    {
        private static ServiceHelper _instance;

        public IVarietyService VarietyService;
        public IOrderService OrderService;
        public IProductService ProductService;

        public void Initialize(ServiceProvider provider)
        {
            VarietyService = provider.GetService<IVarietyService>();
            OrderService = provider.GetService<IOrderService>();
            ProductService = provider.GetService<IProductService>();
        }

        public static ServiceHelper Instance
        {
            get
            {
                if (_instance != null) return _instance;
                else if (_instance == null) _instance = new ServiceHelper();
                return _instance;
            }
        }
    }
}
