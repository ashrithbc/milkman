﻿using Microsoft.AspNetCore.Mvc;
using MilkSupply.Data.Managers;
using MilkSupply.Web.Helpers;
using MilkSupply.Web.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MilkSupply.Web.Controllers
{
    public class SellerController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SellerManager _sellerManager;
        private readonly VarietyManager _varietyManager;

        public SellerController(UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
            _sellerManager = new SellerManager();
            _varietyManager = new VarietyManager();
        }

        [HttpGet]
        [ActionName("Index")]
        
        public async Task<IActionResult> Index()
        
        {
            SellerModel seller = new SellerModel();

            var varietyLst = await _varietyManager.GetAllAsync();
            seller.VarietyList.AddRange(varietyLst.Select(variety => new SelectListItem
            {
                Text = variety.Name,
                Value = variety.Id.ToString()
            }));
            //System.Collections.Generic.List<Data.Models.Status> status = await _statusManager.GetAllAsync();
            //status = status.Where(x => x.Type == "Seller").ToList();
        
            //seller.StatusList.AddRange(status.Select(stat => new SelectListItem
            //{
            //    Text = stat.Description,
            //    Value = stat.Id.ToString()
            //}));
            return View("Index", seller);
        }

        [HttpPost]
        [ActionName("Save")]
        public async Task<IActionResult> Save(SellerModel seller)
        {
            try
            {
                if (string.IsNullOrEmpty(seller.Email))
                {
                    return Json(JsonResponse<string>.ErrorResponse("Email is required."));
                }

                if (string.IsNullOrEmpty(seller.Password) || string.IsNullOrEmpty(seller.ConfirmPassword))
                {
                    return Json(JsonResponse<string>.ErrorResponse("Password & confirm password are required."));
                }

                if (seller.Password != seller.ConfirmPassword)
                {
                    return Json(JsonResponse<string>.ErrorResponse("Password & confirm password are different."));
                }

                var user = new IdentityUser
                {
                    Email = seller.Email,
                    UserName = seller.Email
                };
                var result = await _userManager.CreateAsync(user, seller.Password);
                if (result.Succeeded)
                {
                    result = await _userManager.AddToRoleAsync(user, Data.enums.Role.Seller.ToString());
                    var request = await SellerHelper.MaptoDataModel(seller);

                    await _sellerManager.AddAsync(request);
                }
            }
            catch(Exception ex)
            {
                return Json(JsonResponse<string>.ErrorResponse("Seller addition failed."));
            }
            return Json(JsonResponse<bool>.SuccessResponse(true));
        }
    }
}
