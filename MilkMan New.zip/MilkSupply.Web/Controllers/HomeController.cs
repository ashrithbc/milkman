﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MilkSupply.Data.Managers;
using MilkSupply.Web.Helpers;
using MilkSupply.Web.Models;

namespace MilkSupply.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ProductManager _productService;

        public HomeController()
        {
            _productService = new ProductManager();
        }
        
        public async Task<IActionResult> Index(int id = 0)
        {
            List<ProductModel> products = new List<ProductModel>();
            var source = await _productService.GetAllAsync(id);
            await ProductHelper.MapToViewModel(source, products);
            return View("Index", products);
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View("About");
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View("Contact");
        }

        public IActionResult Privacy()
        {
            return View("Privacy");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
