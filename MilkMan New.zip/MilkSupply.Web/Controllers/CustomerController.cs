﻿using Microsoft.AspNetCore.Mvc;
using MilkSupply.Data.Managers;
using MilkSupply.Web.Helpers;
using MilkSupply.Web.Models;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using MilkSupply.Data.enums;

namespace MilkSupply.Web.Controllers
{
    public class CustomerController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly CustomerManager _customerManager;
        private readonly StatusManager _statusManager;

        public CustomerController(UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
            _customerManager = new CustomerManager();
            _statusManager = new StatusManager();
        }

        [HttpGet]
        [ActionName("Index")]
        
        public async Task<IActionResult> Index()
      
        {
            CustomerModel customer = new CustomerModel();
            return View("Index", customer);
        }

        [HttpPost]
        [ActionName("Save")]
        public async Task<IActionResult> Save(CustomerModel customer)
        {
            try
            {
                if (string.IsNullOrEmpty(customer.Email))
                {
                    return Json(JsonResponse<string>.ErrorResponse("Email is required."));
                }

                if (string.IsNullOrEmpty(customer.Password) || string.IsNullOrEmpty(customer.ConfirmPassword))
                {
                    return Json(JsonResponse<string>.ErrorResponse("Password & confirm password are required."));
                }

                if (customer.Password != customer.ConfirmPassword)
                {
                    return Json(JsonResponse<string>.ErrorResponse("Password & confirm password are different."));
                }

                var user = new IdentityUser
                {
                    Email = customer.Email,
                    UserName = customer.Email
                };
                var result = await _userManager.CreateAsync(user, customer.Password);
                if (result.Succeeded)
                {
                    result = await _userManager.AddToRoleAsync(user, Role.Customer.ToString());

                    var request = await CustomerHelper.MaptoDataModel(customer);

                    await _customerManager.AddAsync(request);
                }
            }
            catch (Exception ex)
            {
                return Json(JsonResponse<string>.ErrorResponse("Customer addition failed."));
            }
            return Json(JsonResponse<bool>.SuccessResponse(true));
        }
    }
}
