﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MilkSupply.Data.Managers;
using MilkSupply.Data.Models;
using MilkSupply.Web.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using MilkSupply.Web.Helpers;

namespace MilkSupply.Web.Controllers
{
    public class ProductController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ProductManager _productManager;
        private readonly VarietyManager _varietyManager;
        private readonly DeliveryTimeManager _deliveryTimeManager;

        public ProductController(UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
            _productManager = new ProductManager();
            _varietyManager = new VarietyManager();
            _deliveryTimeManager = new DeliveryTimeManager();
        }

        [HttpGet]
        [ActionName("Index")]

        public async Task<IActionResult> Index()
        {
            ProductModel product = new ProductModel();
            var varieties = await _varietyManager.GetAllAsync();
            product.Varieties.AddRange(varieties.Select(variety => new SelectListItem
            {
                Text = variety.Name,
                Value = variety.Id.ToString()
            }));
            var slots = await _deliveryTimeManager.GetAllAsync();
            product.Slots.AddRange(slots.Select(slot => new SelectListItem
            {
                Text = slot.Slot,
                Value = slot.Id.ToString()
            }));
            return View("Index", product);
        }



        [HttpPost]
        [ActionName("Save")]
        public async Task<IActionResult> Save(ProductModel product)
        {
            try
            {
                if (string.IsNullOrEmpty(product.Name))
                {
                    return Json(JsonResponse<string>.ErrorResponse("Name is required."));
                }
                if (product.QuantityAvailable == 0)
                {
                    return Json(JsonResponse<string>.ErrorResponse("Quantity Available is required."));
                }
                if (product.Amount <= 0m)
                {
                    return Json(JsonResponse<string>.ErrorResponse("Amount in rupee is required."));
                }

                if (product.AvailabilityTimeId == 0)
                {
                    return Json(JsonResponse<string>.ErrorResponse("Time Availability is required."));
                }

                Product pro = ProductHelper.MapToDataModel(product);
                if (product.Id > 0)
                {
                    pro.Id = product.Id;
                    await _productManager.UpdateAsync(pro);
                }
                else
                {
                    await _productManager.AddAsync(pro);
                }
            }
            catch (Exception ex)
            {
                return Json(JsonResponse<string>.ErrorResponse("Product addition failed."));
            }
            return RedirectToAction("Index", "Home");
        }
    }
}
