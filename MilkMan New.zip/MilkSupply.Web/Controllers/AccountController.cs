﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MilkSupply.Web.Models;
using SignInResult = Microsoft.AspNetCore.Identity.SignInResult;

namespace MilkSupply.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly UserManager<IdentityUser> _userManager;

        public AccountController(SignInManager<IdentityUser> signInManager, UserManager<IdentityUser> userManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
        }

        [HttpGet]
        [ActionName("Index")]
        public IActionResult ChangePassword()
        {
            return View("Index");
        }

        [HttpPost]
        [ActionName("Login")]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(model.Username);
                if (user == null || string.IsNullOrEmpty(user.Id))
                {
                    return Json(
                        JsonResponse<string>.ErrorResponse("Please check the credentials provided. Try again."));
                }

                SignInResult result = await _signInManager.PasswordSignInAsync(model.Username,
                    model.LoginPassword, false, lockoutOnFailure: true);
                if (result.Succeeded)
                {
                    return Json(JsonResponse<bool>.SuccessResponse(true));
                }
                return Json(
                    JsonResponse<string>.ErrorResponse("Please check the credentials provided. Try again."));
            }
            catch (Exception ex)
            {
                return Json(
                    JsonResponse<string>.ErrorResponse("Please check the credentials provided. Try again."));
            }
        }

        [HttpGet]
        [ActionName("ForgotPassword")]
        public IActionResult ForgotPassword()
        {
            return View("ForgotPassword");
        }

        public async Task Logout(string returnUrl = null)
        {
            await _signInManager.SignOutAsync();
        }
    }
}
