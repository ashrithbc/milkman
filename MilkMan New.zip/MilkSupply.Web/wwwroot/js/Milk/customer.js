﻿var Customer = (function () {
    "use strict";



    function saveCustomer(form) {
        $.ajax({
            url: "/Customer/Save",
            beforeSend: function () { $("#wait").show(); },
            type: "POST",
            data: form.serialize(),
            datatype: "json",
            cache: false,
            complete: function () { $("#wait").hide(); },
            sucess: function (data) {
                if (data.sucess) {
                    alert("Customer added successfully.");
                  window.location.href = AppPath + "Home";
                }
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    }

    function SetUpEvents() {

        $("#btnSubmit").click(function (e) {
            e.preventDefault();
            var _form = $(this).closest("form");
            var isValid = _form.valid();

            if (isValid) {
                saveCustomer(_form);
            }
        });
    }

    return {
        SetUpEvents: SetUpEvents
    };
})();