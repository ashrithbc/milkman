﻿var Product = (function () {
    "use strict";




    function saveProduct(form) {
        $.ajax({
            url: "/Product/Save",
            beforeSend: function () { $("#wait").show(); },
            type: "POST",
            data: form.serialize(),
            datatype: "json",
            cache: false,
            complete: function () { $("#wait").hide(); },
            sucess: function (data) {
                if (data.sucess) {
                    alert("Product added successfully.");
                    window.location.href = AppPath + "Home";
                }
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    }

    function setupEvents() {

        $("#btnSubmit").click(function (e) {
            e.preventDefault();
            var _form = $(this).closest("form");
            var isValid = _form.valid();

            if (isValid) {
                saveProduct(_form);
            }
        });
    }

    return {
        setupEvents: setupEvents
    };
})();