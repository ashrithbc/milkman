﻿var Seller = (function () {
    "use strict";

    function saveSeller(form) {
        $.ajax({
            url: "/Seller/Save",
            beforeSend: function () { $("#wait").show(); },
            type: "POST",
            data: form.serialize(),
            datatype: "json",
            cache: false,
            complete: function () { $("#wait").hide(); },
            sucess: function (data) {
                if (data.sucess)
                {
                    alert("Seller added successfully.");
                    window.location.href = AppPath + "Home/Index";
                }
            },
                error: function (xhr, status, error) {
                    alert(xhr.responseText);
                }
            });
    }

    function setupEvents() {

        $("#btnSubmit").click(function (e) {
            e.preventDefault();
            var _form = $(this).closest("form");
            var isValid = _form.valid();

            if (isValid)
            {
                saveSeller(_form);
            }
        });
    }

    return {
        setupEvents: setupEvents
    };
})();