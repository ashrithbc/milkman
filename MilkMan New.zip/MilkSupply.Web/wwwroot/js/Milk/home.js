﻿var Home = (function () {
  "use strict";

  function validateLogin(formdata) {
      $.ajax({
          url: AppPath + "Account/Login",
          beforeSend: function () {
              $(".spinner").show();
          },
          type: "POST",
          data: formdata.serialize(),
          cache: false,
          complete: function () {
              $(".spinner").hide();
          },
          success: function (data) {
              if (data.success) {
                  location.reload();
              }
              else {
                  alert("Login Failed",
                      data.errorMessage);
              }
          },
          error: function (xhr, status, error) {
              alert(xhr.responseText);
          }
      });
  }

  function setUpEvents() {
      $("#btnLogin").unbind().click(function(e) {
          e.preventDefault();
          var _form = $(this).closest("form");
          var isValid = _form.valid();
          if (isValid) {
              validateLogin(_form);
          }
      });
  }

  return {
        setUpEvents: setUpEvents
    };
})();